function [newimg] = image_maker(bigname,smallname,N,M,scale)
%% image generation from smaller image
% load the big image
big = double(imread(bigname)); %change this to whatever

big = imresize(big,scale);
%a scale factor is used if your 'big' picture is actually not that big

% load the small image
small = double(imread(smallname));

% How many chunks do we want to split the big image into?
%N = 5000; %number of chunks to split big into

numpix_big = length(big(:,1,1))*length(big(1,:,1));
numpix_per_chunk_big = numpix_big/N;
len_big = floor(sqrt(numpix_per_chunk_big));

% How many chunks do we want to split the small image into?
%M = 200; %number of chunks to split small into

numpix_small = length(small(:,1,1))*length(small(1,:,1));
numpix_per_chunk_small = numpix_small/M;
len_small = floor(sqrt(numpix_per_chunk_small));

%generating reshaped small
width = length(1:floor(length(small(:,1,1))/len_small));
height = length(1:floor(length(small(1,:,1))/len_small));
reshaped_small = zeros(len_big,len_big,width*height,3);
counter = 1;
for i = 1:width
    for j = 1:height
        tempimage = small(1+len_small*(i-1):len_small*i,1+len_small*(j-1):len_small*j,:);
        reshaped_small(:,:,counter,:) = imresize(tempimage, [len_big len_big]);
        counter = counter + 1;
    end
end
vector_small = reshape(reshaped_small, [len_big*len_big,length(reshaped_small(1,1,:,1)),3]);

% showing the reshaped_small
%for i = 1:length(reshaped_small(1,1,:,1))
%    imshow(uint8(squeeze(reshaped_small(:,:,i,:))))
%    title([num2str(100*i/length(reshaped_small(1,1,:,1))),'%'])
%    drawnow
%end

% making the new image

newimg = zeros(size(big));
width_big = length(1:floor(length(big(:,1,1))/len_big));
height_big = length(1:floor(length(big(1,:,1))/len_big));
for i = 1:width_big
    for j = 1:height_big
        section = big(1+len_big*(i-1):len_big*i,1+len_big*(j-1):len_big*j,:);
        % this section is len_big x len_big x 3
        % compare this section with each of the reshaped_smalls to find
        % the best fit
        vector_section = reshape(section,[len_big*len_big,3]);
        sub = bsxfun(@minus, permute(vector_small,[1,3,2]), vector_section);
        norm_sub = arrayfun(@(idx) norm(sub(:,:,idx)), 1:size(sub,3));
        [B,I] = min(norm_sub);
        newimg(1+len_big*(i-1):len_big*i,1+len_big*(j-1):len_big*j,:) = reshaped_small(:,:,I,:);
    end
end
figure()
image(uint8(newimg))
title([bigname,' made with ',smallname, ' using this many chunks of each ',num2str(N),',',num2str(M)])
end

