function [newimg] = image_maker_HSV(bigname,smallname,M,Scale)
big = double(imread(bigname)); %change this to whatever

%how many chunks do we want the big to be broken up into?
%M = 3000; %number of chunks to split big into

% resize big to make it easier to fit pictures in it
big = imresize(big,Scale);
%scale factor is used if your 'big' picture is actually not that big

% load the small image
small = double(imread(smallname));

% Make the small image square if its not already
height = length(small(:,1,1));
width = length(small(1,:,1));
if height<width
    small = small(:,(end/2)-height/2:(end/2)+height/2,:);
end
if width<height
    small = small((end/2)-width/2:(end/2)+width/2,:,:);
end
%chop off last row/col
small_size = size(small);
if (small_size(2)>small_size(1))
    small = small(:,1:end-1,:);
end
if (small_size(1)>small_size(2))
    small = small(1:end-1,:,:);
end
% now small is perfectly square

% Calculate how we want to split up the big picture
numpix_big = length(big(:,1,1))*length(big(1,:,1));
numpix_per_chunk_big = numpix_big/M;
len_big = floor(sqrt(numpix_per_chunk_big));

% need to resize the small pic to be same size as len_big x len_big
small_resized = imresize(small, [len_big len_big]);
small_resized_hsv = rgb2hsv(small_resized);
small_resized_hsv_vec = reshape(small_resized_hsv,[len_big*len_big,3]);
small_hsv_mean = mean(small_resized_hsv_vec,1);

newimg = zeros(size(big));
width_big = length(1:floor(length(big(:,1,1))/len_big));
height_big = length(1:floor(length(big(1,:,1))/len_big));

%iterate through the big picture
for i = 1:width_big
    for j = 1:height_big
        section = big(1+len_big*(i-1):len_big*i,1+len_big*(j-1):len_big*j,:);
        % this section is len_big x len_big x 3 of the big image
        
        % calculate average HSV for this section
        section_hsv = rgb2hsv(section);
        vect_section_hsv = reshape(section_hsv,[len_big*len_big,3]);
        mean_hsv = mean(vect_section_hsv,1);
        
        factor = mean_hsv./small_hsv_mean;
        
        replace = small_resized_hsv;
        replace(:,:,1) = replace(:,:,1) * factor(1);
        replace(:,:,2) = replace(:,:,2) * factor(2);
        replace(:,:,3) = replace(:,:,3) * factor(3);

        newimg(1+len_big*(i-1):len_big*i,1+len_big*(j-1):len_big*j,:) = hsv2rgb(replace);
    end
end
figure()
image(uint8(newimg))
title([bigname,' made with ',smallname, ' using ', num2str(M),' chunks'])
end

