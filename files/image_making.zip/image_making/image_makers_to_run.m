%% run this file to use the functions
%% First function (image_maker)
first_pic = image_maker('tiger.jpg','dbz2.png',6000,120,1);
%pass in, big picture, small picture, number of big chunks, number of small
%chunks, and scale factor
%scale factor is used if your 'big' picture is actually not that big

%% Second function (image_maker_HSV)
second_pic = image_maker_HSV('trump.jpg','biden.jpg',1500,2);
%pass in, big picture, small picture, number of big chunks, scale factor
%scale factor is used if your 'big' picture is actually not that big