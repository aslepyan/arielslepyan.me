%% run this file to use the functions
%% First function (image_maker)
first_pic = image_maker('tiger.jpg','dbz2.png',5000,120);
%pass in, big picture, small picture, number of big chunks, number of small
%chunks

%% Second function (image_maker_HSV)
second_pic = image_maker_HSV('trump.jpg','biden.jpg',5000);
%pass in, big picture, small picture, number of big chunks