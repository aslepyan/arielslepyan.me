This program uses two pictures to make a new picture.

image_maker attempts to recreate a big picture with pieces of a small picture

image_maker_HSV attempts to recreate a big picture with many examples of the 
small image with different hue/saturation/values

Run image_makers_to_run and put the pics you want to use in the same folder/this folder.